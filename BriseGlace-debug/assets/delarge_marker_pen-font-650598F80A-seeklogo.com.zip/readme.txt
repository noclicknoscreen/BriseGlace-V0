this font is free for you to use, all we ask is that
if you use include it in some commercial work - please let us know:

delarge@delarge.co.uk

ENJOY!!

peace

www.delarge.co.uk




19sep2003